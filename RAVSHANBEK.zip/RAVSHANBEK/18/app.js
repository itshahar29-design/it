// let ism = ['Hasan'];
// let i = 0;
// while (i < ism.length) {
//     console.log(ism[i].split(''));
//     i++;
// }

// let names = ['Azmat'];
// for (let i = 0; i < names.length; i++) {
//     console.log(names[i].toUpperCase());
// }

// let namesList = ['AZAMAT'];
// for (let i = 0; i < namesList.length; i++) {
//     console.log(namesList[i].toLowerCase());
// }

// let namer = ['Azmat', 'Eshmat', 'Dilshod', 'Komil', 'Nodir'];
// let k = 0;
// while (k < namer.length) {
//     console.log((k + 1) + ". " + namer[k]);
//     k++;
// }

// let ismMatn = "Anvar";
// let teskariIsm = ismMatn.split("").reverse().join("");
// console.log(teskariIsm);

// const parol = prompt('PAROL KRITING'); 

// if (parol.length >= 8 && parol.length < 12 && parol.includes('@')) { 
//     console.log("Sizning parolingiz to'g'ri va xavfsiz!"); 
// } else if (parol.length >= 12 || (parol.includes('$%^@') && parol.length >= 5)) { 
//     console.log("Sizning parolingiz juda ham kuchli!"); 
// } else { 
//     console.log("ERROR: Parol talabga javob bermaydi!"); 
// }

// let baho = prompt("Bahoyingizni ayting (A, B, C, D, E, F)");
// switch (baho.toUpperCase()) {
//     case 'A':
//         console.log("A'lo");
//         break;
//     case 'B':
//         console.log("Yaxshi");
//         break;
//     case 'C':
//         console.log("Qoniqarli");
//         break;
//     case 'D':
//         console.log("Qoniqarsiz");
//         break;
//     case 'E':
//         console.log("Yomon");
//         break;
//     case 'F':
//         console.log("Juda yomon (Yiqildi)");
//         break;
//     default:
//         console.log("Noto'g'ri baho kiritildi!");
// }

let kunRaqami = prompt("Hafta kuni raqamini kiriting (1-7):");
switch (parseInt(kunRaqami)) {
    case 1:
        console.log("Dushanba");
        break;
    case 2:
        console.log("Seshanba");
        break;
    case 3:
        console.log("Chorshanba");
        break;
    case 4:
        console.log("Payshanba");
        break;
    case 5:
        console.log("Juma");
        break;
    case 6:
        console.log("Shanba");
        break;
    case 7:
        console.log("Yakshanba");
        break;
    default:
        console.log("Noto'g'ri hafta kuni kiritildi!");
}
