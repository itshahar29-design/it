
// let names = ['Azmat', 'Eshmat', 'Dilshod', 'Komil', 'Nodir'];


// for (let i = 0; i < 10; i++) {
//     console.log(i);
// }


// for (let i = 0; i < names.length; i++) {
//     console.log(names[i].toUpperCase());
// }


// let i = 0;

// while (i < names.length) {
//     console.log(names[i].toUpperCase());
//     i++;
// }


// let i = 5;

// do {
//     i++;
// } while (i < 5);

// console.log(i);


// let yosh = prompt("Yoshingizni kiriting");

// if (yosh >= 18 && yosh <= 27) {
//     console.log("Siz armiyaga borishingiz mumkin");
// } else {
//     console.log("Siz armiya yoshida emassiz");
// }



// if (false && false) {
//     console.log("Hello world");
// }


// if (false || true) {
//     console.log("Hello world");
// }












