

// 1. Array (Massiv) bilan ishlash:

// 'a' nomli o‘zgaruvchiga 3 ta bir xil matndan iborat massiv yaratib olindi
let a = ['ESHMAT','toshmat','qodr'] 

// massivning OXIRIGA yangi bo‘sh matn ('') qo‘shadi. Natija: ['ESHMAT','ESHMAT','ESHMAT', '']
a.push('') 

// massivning OXIRIDAGI elementni o‘chirib tashlaydi (qavs ichiga qiymat yozish shart emas). Natija: ['ESHMAT','ESHMAT','ESHMAT']
a.pop('') 

// massivning BOSHIDAGI elementni o‘chirib tashlaydi (qavs ichiga qiymat yozish shart emas). Natija: ['ESHMAT','ESHMAT']
a.shift('') 

// massivning BOSHIGA yangi bo‘sh matn ('') qo‘shadi. Natija: ['', 'ESHMAT','ESHMAT']
a.unshift('') 

// Massivning yakuniy holatini konsolga (ekranga) chiqaradi
console.log(a) 


// 2. O‘zgaruvchilarning ko‘rinish sohasi (Scope):

// Eng tashqarida global (yoki funksiya) miqyosida age (yosh) degan o‘zgarmas qiymat yaratildi
const age = 24 

// Birinchi shart bloki (har doim ishlaydi, chunki ichida true turibdi)
if (true) { 
  // Shu if blokining ICHIGAlargina tegishli bo‘lgan yangi 'age' o‘zgaruvchisi yaratildi. Tashqaridagi 24 ga ta'sir qilmaydi.
  const age = 25 
  // Faqat shu if bloki ichida ishlaydigan 'ism' o‘zgaruvchisi yaratildi
  const ism = 'ahror' 
  
  // Konsolga if ichidagi 'age' ni, ya'ni 25 ni chiqaradi
   console.log('ikkinchi if ichi:', age) 
  
  // Konsolga shu blok ichidagi age (25) va ism ('ahror') ni chiqaradi
  console.log('if eslsening ichidagi age:', age, ism) 
} 

// Ikkinchi shart bloki (bu ham har doim ishlaydi)
if (true) { 
  // Faqat shu ikkinchi if bloki ichidagina ko‘rinadigan 'age' (30) o‘zgaruvchisi yaratildi
  const age = 30 
  
  // 'var' bilan ochilgan o‘zgaruvchilar blokli skopga (gullik qavslarga) bo‘ysunmaydi.
  // Shuning uchun bu 'test' o‘zgaruvchisini if dan tashqarida ham ishlatsa bo‘ladi.
  var test = 'hello' 
}



